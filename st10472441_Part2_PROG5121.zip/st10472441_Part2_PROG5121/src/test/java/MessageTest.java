/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.st10472441_part2_prog5121.Message;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Scanner;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Omphile
 */
public class MessageTest {
    
     @Test
    public void testMessageIDCreated() {

        Message myMessage = new Message(0);

        assertTrue(myMessage.checkMessageID());
    }

    @Test
    public void testMessageLengthSuccess() {

        Message myMessage = new Message(0);

        myMessage.message = "Hi, how are you?";

        assertEquals("Message ready to send.",
                myMessage.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {

        Message myMessage = new Message(0);

        myMessage.message = "A".repeat(251);

        assertEquals("Message exceeds 250 characters by 1, "
                + "please reduce size.",
                myMessage.checkMessageLength());
    }

    @Test
    public void testRecipientNumberSuccess() {

        Message myMessage = new Message(0);

        myMessage.recipient = "+27718699002";

        assertEquals("Cell phone number successfully captured.",
                myMessage.checkRecipientCell());
    }

    @Test
    public void testRecipientNumberFailure() {

        Message myMessage = new Message(0);

        myMessage.recipient = "08966553";

        assertEquals("Cell number is incorrectly formatted or does not "
                + "contain an international code; please correct "
                + "the number and try again.",
                myMessage.checkRecipientCell());
    }

    @Test
    public void testMessageHash() {

        Message myMessage = new Message(0);

        myMessage.messageID = "0012345678";
        myMessage.messageNumber = 0;
        myMessage.message = "Hi Mike, can you join us for dinner tonight?";

        assertEquals("00:0:HITONIGHT",
                myMessage.createMessageHash());
    }

    @Test
    public void testSendMessage() {

        Message myMessage = new Message(0);

        Message.myInput = new Scanner("1\n");

        assertEquals("Message successfully sent.",
                myMessage.SendMessage());
    }

    @Test
    public void testDisregardMessage() {

        Message myMessage = new Message(0);

        Message.myInput = new Scanner("2\n");

        assertEquals("Press 0 to delete the message.",
                myMessage.SendMessage());
    }

    @Test
    public void testStoreMessage() {

        Message myMessage = new Message(0);

        myMessage.messageID = "0012345678";
        myMessage.messageHash = "00:0:HITONIGHT";
        myMessage.recipient = "+27718699002";
        myMessage.message = "Hi Mike, can you join us for dinner tonight?";

        Message.myInput = new Scanner("3\n");

        assertEquals("Message successfully stored.",
                myMessage.SendMessage());
    }
}
    