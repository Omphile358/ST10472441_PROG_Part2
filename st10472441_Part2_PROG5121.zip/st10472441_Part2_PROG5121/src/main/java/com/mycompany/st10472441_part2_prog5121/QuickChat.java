/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.st10472441_part2_prog5121;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Omphile
 */
public class QuickChat {
     public static void run(Scanner myInput) {

        // Declarations
        int numberOfMessages;
        int choice;
        int messageCount = 0;
        String recipient;
        String messageText;
        String result;

        ArrayList<Message> sentMessages = new ArrayList<>();

        Message.myInput = myInput;

        System.out.println("\nWelcome to QuickChat.");

        System.out.print("How many messages do you want to enter? ");
        numberOfMessages = myInput.nextInt();
        myInput.nextLine();

        while (numberOfMessages < 0) {
            System.out.print("Enter zero or a positive number: ");
            numberOfMessages = myInput.nextInt();
            myInput.nextLine();
        }

        do {
            System.out.println("\nQuickChat Menu");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");

            choice = myInput.nextInt();
            myInput.nextLine();

            switch (choice) {

                case 1:

                    if (messageCount >= numberOfMessages) {
                        System.out.println(
                                "You have entered the requested number "
                                + "of messages.");
                        break;
                    }

                    while (messageCount < numberOfMessages) {

                        Message myMessage =
                                new Message(messageCount);

                        System.out.println("\nMessage "
                                + (messageCount + 1));

                        System.out.print("Enter recipient number (+27): ");
                        recipient = myInput.nextLine();

                        myMessage.recipient = recipient;

                        while (!myMessage.checkRecipientCell().equals(
                                "Cell phone number successfully captured.")) {

                            System.out.println(
                                    myMessage.checkRecipientCell());

                            System.out.print(
                                    "Enter recipient number again: ");

                            recipient = myInput.nextLine();
                            myMessage.recipient = recipient;
                        }

                        System.out.print("Enter your message: ");
                        messageText = myInput.nextLine();

                        myMessage.message = messageText;

                        while (!myMessage.checkMessageLength().equals(
                                "Message ready to send.")) {

                            System.out.println(
                                    myMessage.checkMessageLength());

                            System.out.print(
                                    "Enter your message again: ");

                            messageText = myInput.nextLine();
                            myMessage.message = messageText;
                        }

                        System.out.println(
                                myMessage.checkMessageLength());

                        myMessage.createMessageHash();

                        result = myMessage.SendMessage();

                        System.out.println(result);

                        if (result.equals("Message successfully sent.")) {

                            sentMessages.add(myMessage);

                            System.out.println(
                                    myMessage.printMessages());

                        } else if (result.equals(
                                "Press 0 to delete the message.")) {

                            System.out.print(
                                    "Enter 0 to delete the message: ");

                            String deleteChoice = myInput.nextLine();

                            if (deleteChoice.equals("0")) {
                                System.out.println("Message deleted.");
                            }
                        }

                        messageCount++;
                    }

                    break;

                case 2:

                    if (sentMessages.isEmpty()) {
                        System.out.println("Coming Soon");
                    } else {
                        for (int i = 0; i < sentMessages.size(); i++) {
                            System.out.println(
                                    sentMessages.get(i).printMessages());
                            System.out.println();
                        }
                    }

                    break;

                case 3:
                    System.out.println("Exiting QuickChat.");
                    break;

                default:
                    System.out.println(
                            "Invalid option. Please try again.");
            }

        } while (choice != 3);

        System.out.println("\nTotal messages sent: "
                + new Message(0).returnTotalMessages());
    }
}


