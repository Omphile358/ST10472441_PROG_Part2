/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.st10472441_part2_prog5121;

/**
 *
 * @author Omphile
 */
public class Login {
      // Declarations
    String username;
    String password;
    String cellPhone;
    String registeredUsername;
    String registeredPassword;

    public boolean checkUserName() {

        if (username != null
                && username.contains("_")
                && username.length() <= 5) {
            return true;
        } else {
            return false;
        }
    }

    public boolean checkPasswordComplexity() {

        if (password == null) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {

            char character = password.charAt(i);

            if (Character.isUpperCase(character)) {
                hasCapital = true;
            }

            if (Character.isDigit(character)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(character)) {
                hasSpecial = true;
            }
        }

        return password.length() >= 8
                && hasCapital
                && hasNumber
                && hasSpecial;
    }

    public boolean checkCellPhoneNumber() {

        return cellPhone != null
                && cellPhone.matches("^\\+27[0-9]{9}$");
    }

    public String registerUser() {

        if (!checkUserName()) {

            return "Username is not correctly formatted; please ensure "
                    + "that your username contains an underscore and is "
                    + "no more than five characters in length.";

        } else if (!checkPasswordComplexity()) {

            return "Password is not correctly formatted; please ensure "
                    + "that the password contains at least eight "
                    + "characters, a capital letter, a number, and a "
                    + "special character.";

        } else if (!checkCellPhoneNumber()) {

            return "Cell number is incorrectly formatted or does not "
                    + "contain an international code; please correct "
                    + "the number and try again.";

        } else {

            registeredUsername = username;
            registeredPassword = password;

            return "Registration successful.";
        }
    }

    public String returnLoginStatus(String username, String password) {

        if (registeredUsername != null
                && registeredPassword != null
                && registeredUsername.equals(username)
                && registeredPassword.equals(password)) {

            return "Welcome user, it is great to see you again.";

        } else {

            return "Username or password incorrect, please try again.";
        }
    }
}

