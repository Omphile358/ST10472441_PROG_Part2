/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.st10472441_part2_prog5121;

import java.util.Random;
import java.util.Scanner;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;

/**
 *
 * @author Omphile
 */
public class Message {
    // Declarations
    public String messageID;
    public String recipient;
    public String message;
    public String messageHash;
    public int messageNumber;

    static int totalMessagesSent = 0;
    public static Scanner myInput;

    public Message(int messageNumber) {

        Random random = new Random();

        this.messageNumber = messageNumber;

        long randomID = 1000000000L
                + (long) (random.nextDouble() * 9000000000L);

        messageID = String.valueOf(randomID);
    }

    public boolean checkMessageID() {

        return messageID != null
                && messageID.matches("[0-9]{1,10}");
    }

    public String checkRecipientCell() {

        if (recipient != null
                && recipient.matches("^\\+27[0-9]{9}$")) {

            return "Cell phone number successfully captured.";

        } else {

            return "Cell number is incorrectly formatted or does not "
                    + "contain an international code; please correct "
                    + "the number and try again.";
        }
    }

    public String checkMessageLength() {

        if (message != null && message.length() <= 250) {

            return "Message ready to send.";

        } else if (message == null) {

            return "Message cannot be empty.";

        } else {

            return "Message exceeds 250 characters by "
                    + (message.length() - 250)
                    + ", please reduce size.";
        }
    }

    public String createMessageHash() {

        String firstTwo = messageID.substring(0, 2);
        String[] words = message.trim().split("\\s+");

        String firstWord =
                words[0].replaceAll("[^a-zA-Z0-9]", "");

        String lastWord =
                words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");

        messageHash = (firstTwo + ":" + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();

        return messageHash;
    }

    public String SendMessage() {

        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        System.out.print("Choose an option: ");

        String choice = myInput.nextLine();

        switch (choice) {
            case "1" -> {
                totalMessagesSent++;
                
                return "Message successfully sent.";
            }
            case "2" -> {
                return "Press 0 to delete the message.";
            }
            case "3" -> {
                storeMessage();
                
                return "Message successfully stored.";
            }
            default -> {
                return "Invalid choice.";
            }
        }
    }

    public String printMessages() {

        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    public int returnTotalMessages() {

        return totalMessagesSent;
    }

    public void storeMessage() {

        try {
            Path filePath = Paths.get("messages.json");

            String existing = "[]";

            if (Files.exists(filePath)) {
                existing = new String(
                        Files.readAllBytes(filePath),
                        StandardCharsets.UTF_8).trim();
            }

            if (existing.isEmpty()) {
                existing = "[]";
            }

            String jsonMessage = "{"
                    + "\"MessageID\":\"" + messageID + "\","
                    + "\"MessageHash\":\"" + messageHash + "\","
                    + "\"Recipient\":\"" + escapeJSON(recipient) + "\","
                    + "\"Message\":\"" + escapeJSON(message) + "\""
                    + "}";

            String content = existing.substring(
                    0, existing.lastIndexOf("]")).trim();

            if (content.endsWith("[")) {
                content = content + jsonMessage + "]";
            } else {
                content = content + "," + jsonMessage + "]";
            }

            Files.write(filePath,
                    content.getBytes(StandardCharsets.UTF_8));

        } catch (IOException e) {
            System.out.println("Unable to store message.");
        }
    }

    private String escapeJSON(String value) {

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}

